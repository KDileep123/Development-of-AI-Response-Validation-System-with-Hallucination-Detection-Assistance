# Question 4: Write a Python program to check whether a string is a palindrome.

text = "madam"
cleaned_text = text.lower().replace(" ", "")

if cleaned_text == cleaned_text[::-1]:
    print(text, "is a palindrome")
else:
    print(text, "is not a palindrome")
