5 Python Programming Questions — Program and Output

1. Bubble Sort
   Output: Sorted list: [11, 12, 22, 25, 34, 64, 90]

2. Factorial
   Output:
   Number: 5
   Factorial: 120

3. Fibonacci Sequence
   Output: Fibonacci sequence:
   0 1 1 2 3 5 8 13

4. Palindrome
   Output: madam is a palindrome

5. Prime Number
   Output: 29 is a prime number

Run any program with: python filename.py
