# Question 3: Write a Python program to print the Fibonacci sequence.

terms = 8
a, b = 0, 1

print("Fibonacci sequence:")
for _ in range(terms):
    print(a, end=" ")
    a, b = b, a + b
print()
